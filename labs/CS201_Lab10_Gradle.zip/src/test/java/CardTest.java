import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class CardTest {
	// TODO - define test fixture objects
	
	@Before
	public void setUp() throws Exception {
		// TODO - create test fixture objects
	}
	
	// TODO - add test methods
	
	@Test
	public void testGetSuit() {
		// TODO: test calling getSuit() on your Card objects 
	}
}
