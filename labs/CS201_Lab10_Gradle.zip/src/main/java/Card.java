public class Card {
	// TODO - add fields an methods
}
