import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Remember {
	public static void main(String[] args) throws IOException {
		String fileName = "CS201_Lab06_Gradle/name.txt";
		// TODO: add your code here
	}
}
