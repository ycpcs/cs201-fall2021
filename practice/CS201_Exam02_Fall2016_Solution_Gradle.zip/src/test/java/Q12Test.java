import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

public class Q12Test {
	private List<Integer> notSortedIntList;
	private List<Integer> sortedIntList;
	private List<String> notSortedStringList;
	private List<String> sortedStringList;
	private List<Integer> emptyIntList;
	private List<Integer> oneElementIntList;
	
	@Before
	public void setUp() {
		notSortedIntList = new LinkedList<Integer>(Arrays.asList(
				83, 30, 58, 25, 71, 88, 85, 68, 1, 64
		));
		sortedIntList = new LinkedList<Integer>(Arrays.asList(
				1, 25, 30, 58, 64, 68, 71, 83, 85, 88
		));
		notSortedStringList = new LinkedList<String>(Arrays.asList(
				"warthog", "blue crab", "guinea pig", "parakeet", "ox", "pony"
		));
		sortedStringList = new LinkedList<String>(Arrays.asList(
				"blue crab", "guinea pig", "ox", "parakeet", "pony", "warthog"
		));
		emptyIntList = new LinkedList<Integer>();
		oneElementIntList = new LinkedList<Integer>(Arrays.asList(42));
	}
	
	@Test
	public void testIsNotSortedIntList() throws Exception {
		assertFalse(Q12.isSorted(notSortedIntList));
	}
	
	@Test
	public void testIsSortedIntList() throws Exception {
		assertTrue(Q12.isSorted(sortedIntList));
	}
	
	@Test
	public void testNotSortedStringList() throws Exception {
		assertFalse(Q12.isSorted(notSortedStringList));
	}
	
	@Test
	public void testSortedStringList() throws Exception {
		assertTrue(Q12.isSorted(sortedStringList));
	}
	
	@Test
	public void testEmptyIntList() throws Exception {
		assertTrue(Q12.isSorted(emptyIntList));
	}
	
	@Test
	public void testOneElementIntList() throws Exception {
		assertTrue(Q12.isSorted(oneElementIntList));
	}
}
