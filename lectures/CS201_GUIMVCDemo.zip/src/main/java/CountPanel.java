import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

// This is a view for CountModel.
public class CountPanel extends JPanel {
	private CountModel model;
	private CountController controller;
	
	public CountPanel() {
		setPreferredSize(new Dimension(200, 200));
		setBackground(Color.GRAY);
		
		// register event handlers!
		addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				handleMouseClick(e);
			}
		});

		addKeyListener(new KeyListener() {

			@Override
			public void keyTyped(KeyEvent e) {
				handleKeyTyped(e);								
			}

			@Override
			public void keyPressed(KeyEvent e) {
			}

			@Override
			public void keyReleased(KeyEvent e) {
			}
			
		});
	}
	
	// Handle mouse clicks
	private void handleMouseClick(MouseEvent e) {
		// Use the controller to update the data in the model
		if (e.getButton() == MouseEvent.BUTTON1) {
			// left click
			controller.increaseCount(model);
		} else if (e.getButton() == MouseEvent.BUTTON3) {
			// right click
			controller.decreaseCount(model);
		}
		
		// Schedule a paint event
		repaint();
	}
	
	// Handle keys typed
	private void handleKeyTyped(KeyEvent e) {
		char c = e.getKeyChar();
		if (Character.isDigit(c)) {
			controller.setCount(model, Character.getNumericValue(c));
		}
		
		// Schedule a paint event
		repaint();
	}
	
	public void setModel(CountModel model) {
		this.model = model;
	}
	
	public void setController(CountController controller) {
		this.controller = controller;
	}
	
	@Override
	protected void paintComponent(Graphics g) {
		// draw background
		super.paintComponent(g);
		
		// Do drawing operations to render the data
		// in the model
		Font f = new Font(Font.DIALOG, Font.BOLD, 64);
		String countAsString = String.valueOf(model.get());
		
		g.setFont(f);
		g.setColor(Color.GREEN);
		g.drawString(countAsString, 20, 50);
	}
	
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				JFrame frame = new JFrame();
				
				CountPanel view = new CountPanel();
				view.setModel(new CountModel());
				view.setController(new CountController());
				
				frame.setContentPane(view);
				
				frame.pack();
				
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				
				frame.setVisible(true);
			}
		});
	}
}
