import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;

// This is a container class for the panel GUI.
public class CountFrame extends JFrame {
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				CountFrame frame = new CountFrame();
				
				CountPanel view = new CountPanel();
				view.setModel(new CountModel());
				view.setController(new CountController());
				view.setFocusable(true);
				view.requestFocusInWindow();
				
				frame.getContentPane().add(view, BorderLayout.CENTER);
				
				frame.pack();
				
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				
				frame.setVisible(true);
			}
		});
	}
}
