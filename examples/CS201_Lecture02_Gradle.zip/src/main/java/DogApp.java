// Dog application
public class DogApp {
    public static void main(String[] args) {
    	// Create a REFERENCE for a Dog object
    	Dog lassie;
    	// Allocate a "new" Dog object (calling the constructor) 
    	//          and assign the reference to it
    	lassie = new Dog("Lassie", true);
    	
    	// Create a reference and allocate a Dog object in one step
    	Dog rex = new Dog("Rex", false);
    	
    	// Create two references for Dog objects
    	Dog rover1, rover2;
    	
    	// Allocate a "new" Dog object and assign a reference to it
    	rover1 = new Dog("Rover", false);
    	
    	// Assign one reference to another (now referring to same object)
    	rover2 = rover1;
    	
    	// Call class methods on references
    	rover1.respondToCall("Rover");
    	rover2.respondToCall("Rover");
    	
    	// Modify object through rover1 reference
    	rover1.train();
    	
     	// Call class methods on references (note both are changed since
     	//      references are to same object)
    	rover1.respondToCall("Rover");
    	rover2.respondToCall("Rover");
 
 		// Create two separate Dog objects with same field values
 		Dog spot = new Dog("Spot", true);
 		Dog anotherSpot = new Dog("Spot", true);
 		
 		// Testing spot references with == fails since separate objects
 		//       (even though fields are the same)
 		if (spot == anotherSpot) {
 			System.out.println("Spots are the same dog");
 		} else {
 			System.out.println("Spots are different dogs");
 		}
 		
 		// Testing rover references with == succeeds since refer to same object
 		if (rover1 == rover2) {
 			System.out.println("Rovers are the same dog");
 		} else {
 			System.out.println("Rovers are different dog");
 		}
 		
 		// Test for same field values with equals()
 		if (spot.equals(anotherSpot)) {
 			System.out.println("Spots have the same fields");
 		} else {
 			System.out.println("Spots have different fields");
 		}
 		
 		// Can't call methods on references that are not referring to an object
 		Dog snoopy;
 		snoopy.respondToCall("Snoopy");
}
