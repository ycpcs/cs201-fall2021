import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class FindLongestLine {
    public static final String PATH = "CS201_Lecture06_Gradle/";

    public static void main(String[] args) throws IOException {
        Scanner keyboard = new Scanner(System.in);

        System.out.println("Which file?");
        String fileName = keyboard.next();

        FileReader fileReader = new FileReader(PATH+fileName);
        BufferedReader reader = new BufferedReader(fileReader);

        int longest = 0;

        while (true) {
   
            String line = reader.readLine();
            if (line == null) {
                break;
            }

            if (line.length() > longest) {
                longest = line.length();
            }
        }

        reader.close();

        System.out.println("The longest line contained " + longest + " character(s)");
    }
}