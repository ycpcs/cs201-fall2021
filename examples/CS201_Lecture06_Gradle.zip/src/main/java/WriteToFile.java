import java.io.FileWriter;
import java.io.IOException;

public class WriteToFile {
    public static void main(String[] args) throws IOException {
        FileWriter writer = new FileWriter("pandp.txt",true);
        
        writer.write("It is a truth universally acknowledged, that a single man in\n");
        writer.write("possession of a good fortune, must be in want of a wife.\n");

        writer.close();

        System.out.println("File written successfully!");
    }
}
