import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class CountVowels {
    public static final String PATH = "CS201_Lecture06_Gradle/";

    public static void main(String[] args) throws IOException {
        Scanner keyboard = new Scanner(System.in);

        String fileName;
        System.out.println("Which file? ");
        fileName = keyboard.next();
        keyboard.close();

        FileReader reader = new FileReader(PATH+fileName);

        int vowelCount = 0;

        while (true){
            int c = reader.read();

            if (c < 0) {
                break;
            }

            char ch = (char) c;
            ch = Character.toLowerCase(ch);
            if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u') {
                vowelCount++;
            }
        }
        reader.close();

        System.out.println("The file contains " + vowelCount + " vowel(s)");
    }
}