import java.util.Scanner;

public class Hello {
	// Java application method
    public static void main(String[] args) {
    	// Basic console output
    	System.out.println("Hello World!");
    
    	// Basic console input (of String data)
        Scanner keyboard = new Scanner(System.in);
        System.out.println("What is your name?");
        String name = keyboard.next();
        
        System.out.println("Hello, " + name);

		// Basic console input (of integer data) with computation
		System.out.println("Enter two integers:");
		int a = keyboard.nextInt();
		int b = keyboard.nextInt();
		
		// Arithmetic same as C
		int sum = a + b;
		
		// Output using concatenation and auto conversion
		System.out.println("The sum is " + sum);
    }
}