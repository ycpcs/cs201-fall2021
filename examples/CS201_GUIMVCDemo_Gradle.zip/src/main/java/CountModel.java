public class CountModel {
	private int count;
	
	public CountModel() {
		count = 0;
	}
	
	public void increase() {
		count++;
	}
	
	public void decrease() {
		count--;
	}
	
	public int get() {
		return count;
	}
	
	public void setCount(int count) {
		this.count = count;
	}
}
