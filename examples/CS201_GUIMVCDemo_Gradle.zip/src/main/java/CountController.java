public class CountController {
	public void increaseCount(CountModel model) {
		model.increase();
	}
	
	public void decreaseCount(CountModel model) {
		model.decrease();
	}
	
	public void setCount(CountModel model, int count) {
		model.setCount(count);
	}
}
