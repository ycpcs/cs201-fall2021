public class ArrayList {
    private static final int INITIAL_CAPACITY = 4;

    private Object[] storage;
    private int numElements;

    public ArrayList() {
        this.storage = new Object[INITIAL_CAPACITY];
        this.numElements = 0;
    }

    public void add(Object elt) {
        if (numElements >= storage.length) {
            grow();
        }
        storage[numElements] = elt;
        numElements++;
    }

    public int size() {
        return numElements;
    }

    public Object get(int index) {
        if (index < 0 || index >= numElements) {
            throw new IndexOutOfBoundsException();
        }
        return storage[index];
    }

    private void grow() {
        Object[] larger = new Object[numElements * 2];
        for (int i = 0; i < storage.length; i++) {
            larger[i] = storage[i];
        }
        storage = larger;
    }
}