import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class ReadLineExceptFinally {
    public static void main(String[] args) {
        try {
    		// The readFirstLine() method might throw a
    		// FileNotFoundException or an IOException
    		String firstLine = readFirstLine("pandp.txt");

    		System.out.println("The first line of pandp.txt is:");
    		System.out.println(firstLine);
		} catch (IOException e) {
    		System.out.println("Error: " + e.getMessage());
		}
    }
    
	public static String readFirstLine(String fileName) throws IOException {
    	FileReader fr = new FileReader(fileName);
    	BufferedReader br = new BufferedReader(fr);
		String firstLine;
	
    	try {
        	firstLine = br.readLine();
    	} finally {
        	br.close();
    	}
    	return firstLine;
	}
}