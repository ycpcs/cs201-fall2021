public class MandelbrotTask implements Runnable {
    private double x1, y1, x2, y2;
    private int startCol, endCol, startRow, endRow;
    private int[][] iterCounts;

	// TODO: Add constructor to set bounds for task
    public MandelbrotTask(double x1, double y1, double x2, double y2,
                          int startCol, int endCol, int startRow, int endRow,
                          int[][] iterCounts) {
	
	}

	// Method to compute all iteration counts for region
	public void run() {
		// TODO: Loop over array extents to compute iterations for each point
		
	}

	// Method to determine the number of iterations beginning with value c
	private int computeIterCount(Complex c) {
		int count = 0;

		// TODO: Iterate Mandelbrot equation up to MandelBrot.THRESHOLD

		return count;
	}
	
	// Method to determine the complex value from the bounds and array indicies
	private Complex getComplex(int row, int col) {
		Complex c;
		
		// TODO: Compute the complex value from the region bounds and
		//       the given array indicies
		
		return c;
	}
}
