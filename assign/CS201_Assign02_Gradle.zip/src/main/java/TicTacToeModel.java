/**
 * An instance of the TicTacToeModel class represents the
 * state of a tic-tac-toe game.
 */
public class TicTacToeModel {
	public static final int PLAYER_O = 0;
	public static final int PLAYER_X = 1;
	public static final int EMPTY = 2;
	
	// TODO: Field for current player
	
	// TODO: Field for the board array	

	
	/**
	 * Constructor.
	 * Initialize the board array to EMPTY
	 * and start with PLAYER_X.
	 * 
	 */
	public TicTacToeModel() {

	}
	
	/**
	 * @return the model's current player's turn
	 */
	public int getTurn() {
		throw new UnsupportedOperationException("not implemented yet");
	}

	/**
	 * @return the model's current board
	 */
	public int[][] getBoard() {
		throw new UnsupportedOperationException("not implemented yet");
	}

	/**
	 * Return the current board location
	 * @param row the row index
	 * @param col the column index
	 * @return the contents of the board at the given location
	 */
	public int getCell(int row, int col) {
		throw new UnsupportedOperationException("not implemented yet");
	}

	/**
	 * Place the marker for the current player on the board and
	 * update the turn.
	 * It is assumed that this method will only be called for
	 * legal moves.
	 *
	 * @param row the row index where the marker is being placed
	 * @param col the column index where the marker is being placed
	 */
	public void placeMarker(int row, int col) {
		throw new UnsupportedOperationException("not implemented yet");
	}

	/**
	 * Switch the current player
	 *
	 */
	public void updateTurn() {
		throw new UnsupportedOperationException("not implemented yet");
	}




















	/**
	 * Constructor FOR TESTING ONLY.
	 * DO NOT USE THIS CONSTRUCTOR
	 * 
	 */
	public TicTacToeModel(int[][] board, int turn) {
		this.board = board;
		this.turn = turn;
	}

}
