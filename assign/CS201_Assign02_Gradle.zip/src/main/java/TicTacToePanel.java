import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JPanel;

public class TicTacToePanel extends JPanel {
	private static final long serialVersionUID = 1L;

	private static final int WIDTH = 300;
	private static final int HEIGHT = 300;
	private static final Font FONT = new Font("Dialog", Font.BOLD, 24);
	
	// TODO: Add fields for model, controller, and end game flags

	
	// constructor
	public TicTacToePanel() {
		// TODO: Initialize fields

		setPreferredSize(new Dimension(WIDTH, HEIGHT));
		setBackground(Color.BLACK);
		
		addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) { handleMouseClick(e); }
		});
		
		// Register event handlers (DO NOT CHANGE)
		addKeyListener(new KeyListener() {

			@Override
			public void keyTyped(KeyEvent e) {}

			@Override
			public void keyPressed(KeyEvent e) { handleKeyTyped(e); }

			@Override
			public void keyReleased(KeyEvent e) {}
			
		});
	}
	
	private void handleMouseClick(MouseEvent e) {
		// TODO: Player attempting to place marker on the board

	}
	
	private void handleKeyTyped(KeyEvent e) {
		// TODO: Save for 's' and load for 'l'

	}
	
	@Override
	public void paint(Graphics g) {
		super.paint(g); // paint background

		// Draw the tic-tac-toe board (DO NOT MODIFY)
		g.setColor(Color.WHITE);
		for (int i = 1; i < 4; i++) {
			// Vertical line
			g.drawLine(i*(WIDTH/3), 0, i*(WIDTH/3), HEIGHT-1);
			// Horizontal line
			g.drawLine(0, i*(HEIGHT/3), WIDTH-1, i*(HEIGHT/3));
		}
		
		// TODO: Draw markers

		// TODO: Draw end game messages if necessary		
		
	}
}
